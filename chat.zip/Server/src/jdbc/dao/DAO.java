package jdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DAO {

    public static Connection con;

    public DAO() {
        if (con == null) {
            String dbUrl = "jdbc:mysql://167.71.209.103:3306/chat-app-swing?autoReconnect=true&useSSL=false";
            String dbClass = "com.mysql.cj.jdbc.Driver";

            try {
                Class.forName(dbClass);
                con = DriverManager.getConnection(dbUrl, "phamthainb", "j2G-72!kjVA*yDY");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
